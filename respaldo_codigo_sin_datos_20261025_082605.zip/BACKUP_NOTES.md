# Respaldo de c?digo (sanitizado)

Se excluyeron `.env*`, bases SQLite/DB, entornos, cach?s, logs y carpetas internas de herramientas. En `app.py` se vaciaron diccionarios de usuarios/datos de demostraci?n. En `database.sql` se quitaron sentencias de inserci?n de usuarios y pacientes, conservando el esquema. Los originales no fueron modificados. No contiene la base activa ni datos de pacientes.
